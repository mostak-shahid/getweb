import React from 'react'
import HeaderComponent from '../Components/Header/HeaderComponent'

const Header = () => {
  return (
        <HeaderComponent />
  )
}

export default Header